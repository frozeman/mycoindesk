(function () {

/* Package-scope variables */
var TemplateVar;



/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['frozeman:template-var'] = {}, {
  TemplateVar: TemplateVar
});

})();
