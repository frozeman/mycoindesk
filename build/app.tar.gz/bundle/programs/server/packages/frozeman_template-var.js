(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var TemplateVar;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['frozeman:template-var'] = {
  TemplateVar: TemplateVar
};

})();

//# sourceMappingURL=frozeman_template-var.js.map
