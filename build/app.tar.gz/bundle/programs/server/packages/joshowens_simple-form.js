(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['joshowens:simple-form'] = {};

})();

//# sourceMappingURL=joshowens_simple-form.js.map
