(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Router = Package['iron:router'].Router;
var RouteController = Package['iron:router'].RouteController;
var T9n = Package['softwarerero:accounts-t9n'].T9n;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var ServiceConfiguration = Package['service-configuration'].ServiceConfiguration;
var Accounts = Package['accounts-base'].Accounts;
var _ = Package.underscore._;
var Iron = Package['iron:core'].Iron;

/* Package-scope variables */
var __coffeescriptShare, AccountsEntry;

(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// packages/meteorblackbelt_accounts-entry/server/entry.coffee.js                                    //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.startup(function() {                                                                          // 1
  var AccountsEntry;                                                                                 // 2
  Accounts.urls.resetPassword = function(token) {                                                    // 2
    return Meteor.absoluteUrl('reset-password/' + token);                                            //
  };                                                                                                 //
  Accounts.urls.enrollAccount = function(token) {                                                    // 2
    return Meteor.absoluteUrl('enroll-account/' + token);                                            //
  };                                                                                                 //
  AccountsEntry = {                                                                                  // 2
    settings: {},                                                                                    // 9
    config: function(appConfig) {                                                                    // 9
      return this.settings = _.extend(this.settings, appConfig);                                     //
    }                                                                                                //
  };                                                                                                 //
  this.AccountsEntry = AccountsEntry;                                                                // 2
  return Meteor.methods({                                                                            //
    entryValidateSignupCode: function(signupCode) {                                                  // 17
      check(signupCode, Match.OneOf(String, null, void 0));                                          // 18
      return !AccountsEntry.settings.signupCode || signupCode === AccountsEntry.settings.signupCode;
    },                                                                                               //
    entryCreateUser: function(user) {                                                                // 17
      var profile, userId;                                                                           // 22
      check(user, Object);                                                                           // 22
      profile = AccountsEntry.settings.defaultProfile || {};                                         // 22
      if (user.username) {                                                                           // 24
        userId = Accounts.createUser({                                                               // 25
          username: user.username,                                                                   // 26
          email: user.email,                                                                         // 26
          password: user.password,                                                                   // 26
          profile: _.extend(profile, user.profile)                                                   // 26
        });                                                                                          //
      } else {                                                                                       //
        userId = Accounts.createUser({                                                               // 31
          email: user.email,                                                                         // 32
          password: user.password,                                                                   // 32
          profile: _.extend(profile, user.profile)                                                   // 32
        });                                                                                          //
      }                                                                                              //
      if (user.email && Accounts._options.sendVerificationEmail) {                                   // 35
        return Accounts.sendVerificationEmail(userId, user.email);                                   //
      }                                                                                              //
    }                                                                                                //
  });                                                                                                //
});                                                                                                  // 1
                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                   //
// packages/meteorblackbelt_accounts-entry/shared/router.coffee.js                                   //
//                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var exclusions;                                                                                      // 1
                                                                                                     //
Router.map(function() {                                                                              // 1
  this.route("entrySignIn", {                                                                        // 3
    path: "/sign-in",                                                                                // 4
    onBeforeAction: function() {                                                                     // 4
      Session.set('buttonText', 'in');                                                               // 6
      return this.next();                                                                            //
    },                                                                                               //
    onStop: function() {                                                                             // 4
      return Session.set('entryError', void 0);                                                      //
    },                                                                                               //
    onRun: function() {                                                                              // 4
      var pkgRendered, userRendered;                                                                 // 11
      if (Meteor.userId()) {                                                                         // 11
        Router.go(AccountsEntry.settings.dashboardRoute);                                            // 12
      }                                                                                              //
      if (AccountsEntry.settings.signInTemplate) {                                                   // 14
        this.template = AccountsEntry.settings.signInTemplate;                                       // 15
        pkgRendered = Template.entrySignIn.rendered;                                                 // 15
        userRendered = Template[this.template].rendered;                                             // 15
        if (userRendered) {                                                                          // 23
          Template[this.template].rendered = function() {                                            // 24
            pkgRendered.call(this);                                                                  // 25
            return userRendered.call(this);                                                          //
          };                                                                                         //
        } else {                                                                                     //
          Template[this.template].rendered = pkgRendered;                                            // 28
        }                                                                                            //
        Template[this.template].events(AccountsEntry.entrySignInEvents);                             // 15
        Template[this.template].helpers(AccountsEntry.entrySignInHelpers);                           // 15
      }                                                                                              //
      return this.next();                                                                            //
    }                                                                                                //
  });                                                                                                //
  this.route("entrySignUp", {                                                                        // 3
    path: "/sign-up",                                                                                // 36
    onBeforeAction: function() {                                                                     // 36
      Session.set('buttonText', 'up');                                                               // 38
      return this.next();                                                                            //
    },                                                                                               //
    onStop: function() {                                                                             // 36
      return Session.set('entryError', void 0);                                                      //
    },                                                                                               //
    onRun: function() {                                                                              // 36
      var pkgRendered, userRendered;                                                                 // 43
      if (AccountsEntry.settings.signUpTemplate) {                                                   // 43
        this.template = AccountsEntry.settings.signUpTemplate;                                       // 44
        pkgRendered = Template.entrySignUp.rendered;                                                 // 44
        userRendered = Template[this.template].rendered;                                             // 44
        if (userRendered) {                                                                          // 52
          Template[this.template].rendered = function() {                                            // 53
            pkgRendered.call(this);                                                                  // 54
            return userRendered.call(this);                                                          //
          };                                                                                         //
        } else {                                                                                     //
          Template[this.template].rendered = pkgRendered;                                            // 57
        }                                                                                            //
        Template[this.template].events(AccountsEntry.entrySignUpEvents);                             // 44
        Template[this.template].helpers(AccountsEntry.entrySignUpHelpers);                           // 44
      }                                                                                              //
      return this.next();                                                                            //
    }                                                                                                //
  });                                                                                                //
  this.route("entryForgotPassword", {                                                                // 3
    path: "/forgot-password",                                                                        // 65
    onStop: function() {                                                                             // 65
      return Session.set('entryError', void 0);                                                      //
    }                                                                                                //
  });                                                                                                //
  this.route('entrySignOut', {                                                                       // 3
    path: '/sign-out',                                                                               // 70
    onBeforeAction: function() {                                                                     // 70
      if (!AccountsEntry.settings.homeRoute) {                                                       // 72
        return this.next();                                                                          //
      } else {                                                                                       //
        return Meteor.logout(function() {                                                            //
          return Router.go(AccountsEntry.settings.homeRoute);                                        //
        });                                                                                          //
      }                                                                                              //
    },                                                                                               //
    onStop: function() {                                                                             // 70
      return Session.set('entryError', void 0);                                                      //
    }                                                                                                //
  });                                                                                                //
  this.route('entryVerificationPending', {                                                           // 3
    path: '/verification-pending',                                                                   // 81
    onStop: function() {                                                                             // 81
      return Session.set('entryError', void 0);                                                      //
    }                                                                                                //
  });                                                                                                //
  this.route('entryResetPassword', {                                                                 // 3
    path: 'reset-password/:resetToken',                                                              // 86
    onBeforeAction: function() {                                                                     // 86
      Session.set('resetToken', this.params.resetToken);                                             // 88
      return this.next();                                                                            //
    },                                                                                               //
    onStop: function() {                                                                             // 86
      return Session.set('entryError', void 0);                                                      //
    }                                                                                                //
  });                                                                                                //
  return this.route('entryEnrollAccount', {                                                          //
    path: 'enroll-account/:resetToken',                                                              // 94
    onBeforeAction: function() {                                                                     // 94
      Session.set('resetToken', this.params.resetToken);                                             // 96
      return this.next();                                                                            //
    },                                                                                               //
    onStop: function() {                                                                             // 94
      return Session.set('entryError', void 0);                                                      //
    }                                                                                                //
  });                                                                                                //
});                                                                                                  // 1
                                                                                                     //
exclusions = [];                                                                                     // 1
                                                                                                     //
_.each(Router.routes, function(route) {                                                              // 1
  return exclusions.push(route.name);                                                                //
});                                                                                                  // 103
                                                                                                     //
Router.onStop(function() {                                                                           // 1
  var ref;                                                                                           // 108
  if (!_.contains(exclusions, (ref = Router.current().route) != null ? ref.getName() : void 0)) {    // 108
    return Session.set('fromWhere', Router.current().path);                                          //
  }                                                                                                  //
});                                                                                                  // 106
                                                                                                     //
///////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['meteorblackbelt:accounts-entry'] = {}, {
  AccountsEntry: AccountsEntry
});

})();

//# sourceMappingURL=meteorblackbelt_accounts-entry.js.map
