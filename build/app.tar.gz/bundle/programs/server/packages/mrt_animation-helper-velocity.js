(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:animation-helper-velocity'] = {};

})();

//# sourceMappingURL=mrt_animation-helper-velocity.js.map
